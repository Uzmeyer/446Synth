/*
 * SystemCommon.h
 *
 *  Created on: 13.09.2019
 *      Author: Jakob
 */

#ifndef SYSTEMCOMMON_H_
#define SYSTEMCOMMON_H_
namespace glock
{
	//#define STM32
#define WIN

#define MAX_VOICES 16
#define MAX_INSTRUMENTS 4


}
#endif /* SYSTEMCOMMON_H_ */
