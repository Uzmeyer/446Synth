/*
 * TimedSynthComponent.cpp
 *
 *  Created on: 27.05.2019
 *      Author: Jakob
 */

#include "TimedSynthComponent.h"
namespace glock
{
	TimedSynthComponent::TimedSynthComponent() {
		// TODO Auto-generated constructor stub

	}

	TimedSynthComponent::~TimedSynthComponent() {
		// TODO Auto-generated destructor stub
	}

	float TimedSynthComponent::run()
	{
		return 0.0f;
	}

}