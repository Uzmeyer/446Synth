/*
 * SynthState.cpp
 *
 *  Created on: 27.05.2019
 *      Author: Jakob
 */

#include "SynthState.h"

namespace glock
{
	SynthState::SynthState() {
		// TODO Auto-generated constructor stub

	}

	SynthState::~SynthState() {
		// TODO Auto-generated destructor stub
	}

}