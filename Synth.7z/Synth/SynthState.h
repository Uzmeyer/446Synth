/*
 * SynthState.h
 *
 *  Created on: 27.05.2019
 *      Author: Jakob
 */

#ifndef SYNTHSTATE_H_
#define SYNTHSTATE_H_
namespace glock
{
	class SynthState {
	public:
		SynthState();
		virtual ~SynthState();
	};
}
#endif /* SYNTHSTATE_H_ */
