/*
 * HardwareHandler.cpp
 *
 *  Created on: 09.09.2019
 *      Author: Jakob
 */

#include "HardwareHandler.h"
namespace glock
{
	HardwareHandler::HardwareHandler() {
		// TODO Auto-generated constructor stub

	}

	HardwareHandler::~HardwareHandler() {
		// TODO Auto-generated destructor stub
	}
}
