/*
 * VirtualPatch.cpp
 *
 *  Created on: 09.09.2019
 *      Author: Jakob
 */

#include "VirtualPatch.h"
namespace glock
{
	/*
	VirtualPatch defaultPatch =
	{

	};
	*/
}

