/*
 * LFO.cpp
 *
 *  Created on: 08.09.2019
 *      Author: Jakob
 */

#include "LFO.h"
namespace glock
{
	LFO::LFO() {
		// TODO Auto-generated constructor stub

	}

	LFO::~LFO() {
		// TODO Auto-generated destructor stub
	}

}