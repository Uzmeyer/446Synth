/*
 * HardwareHandler.h
 *
 *  Created on: 09.09.2019
 *      Author: Jakob
 */

#ifndef HARDWAREHANDLER_H_
#define HARDWAREHANDLER_H_
namespace glock
{
	class HardwareHandler {
	public:
		HardwareHandler();
		virtual ~HardwareHandler();
	};
}
#endif /* HARDWAREHANDLER_H_ */
