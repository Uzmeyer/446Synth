/*
 * Filter.cpp
 *
 *  Created on: 08.09.2019
 *      Author: Jakob
 */

#include "Filter.h"
namespace glock
{
	Filter::Filter() {
		// TODO Auto-generated constructor stub

	}

	Filter::~Filter() {
		// TODO Auto-generated destructor stub
	}

}

