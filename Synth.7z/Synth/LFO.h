/*
 * LFO.h
 *
 *  Created on: 08.09.2019
 *      Author: Jakob
 */

#ifndef LFO_H_
#define LFO_H_

#include "TimedSynthComponent.h"
namespace glock
{
	class LFO : public TimedSynthComponent {
	public:
		LFO();
		virtual ~LFO();
	};
}
#endif /* LFO_H_ */
