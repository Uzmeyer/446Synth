/*
 * SynthComponent.cpp
 *
 *  Created on: 18.05.2019
 *      Author: Jakob
 */

#include "SynthComponent.h"

namespace glock
{

	SynthComponent::SynthComponent() {
		// TODO Auto-generated constructor stub

	}

	SynthComponent::~SynthComponent() {
		// TODO Auto-generated destructor stub
	}

	float SynthComponent::getCurrentValue()
	{
		return currentValue;
	}

}
